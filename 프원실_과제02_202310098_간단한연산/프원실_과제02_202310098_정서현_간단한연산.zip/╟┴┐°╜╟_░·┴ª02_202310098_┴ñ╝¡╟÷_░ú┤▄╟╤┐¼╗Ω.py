
temp_c = 30
temp_f = temp_c * 1.8 + 32
print(temp_f)

temp_c = 0
temp_f = temp_c * 1.8 + 32
print(temp_f)

height = 1.58
weight = 47
bmi = weight / height ** 2
print(bmi)

radius = 4
area = radius ** 2
print(area)

lower = 5
upper = 3
height = 4
trapezoid = (lower + upper) * height / 2
print(trapezoid)
